GLOBAL PAGINATION STANDARDIZATION
=================================

Tujuan
------
Menjadikan pagination satu komponen CSS global untuk:
- Pengurusan Pengguna
- Pengurusan Tempahan
- Pengurusan Bilik
- Audit Log

Class standard baru
-------------------
app-pagination
app-page-link
app-page-arrow
app-page-ellipsis

Fail dalam pakej
----------------
1. style.css
   CSS penuh semasa + global pagination.
   Class audit-* lama masih disokong untuk backward compatibility.

2. migrate_pagination_classes.ps1
   Menukar class pagination pada template semasa anda sendiri.
   Setiap fail akan dibackup sebagai .bak sebelum diubah.

Cara guna
---------
1. Gantikan:
   app/static/css/style.css
   dengan style.css daripada pakej ini.

2. Simpan migrate_pagination_classes.ps1 di root projek:
   C:\laragon\www\meeting-room-booking

3. Dalam PowerShell di root projek, jalankan:
   .\migrate_pagination_classes.ps1

4. Refresh aplikasi dan uji:
   - Pengurusan Pengguna
   - Pengurusan Tempahan
   - Pengurusan Bilik
   - Audit Log

Nota
----
Skrip hanya menukar nama class CSS pagination.
Ia tidak mengubah route Flask, query, filter, search, tarikh, atau nilai per_page.
